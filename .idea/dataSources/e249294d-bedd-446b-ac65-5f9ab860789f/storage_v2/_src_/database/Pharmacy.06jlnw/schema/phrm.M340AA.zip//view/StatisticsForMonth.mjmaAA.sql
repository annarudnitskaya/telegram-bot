CREATE VIEW phrm.StatisticsForMonth
AS
SELECT cl.ClientID, cl.FullName, SUM(sa.PurchaseAmount) AS PurchaseAmountForMonth
FROM  phrm.Clientes AS cl JOIN phrm.Sales AS sa ON sa.ClientID = cl.ClientID 
WHERE cl.ClientID = sa.ClientID AND MONTH(sa.Date) = MONTH(GETDATE())
GROUP BY cl.ClientID, cl.FullName
go

