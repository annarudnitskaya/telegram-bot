CREATE FUNCTION phrm.udfClientesSales(@Recipe BIT, @PurchaseAmount INT)
RETURNS TABLE
AS
RETURN(
SELECT  sa.PurchaseAmount, cl.FullName, di.AmountOfRansom
FROM phrm.Clientes AS cl JOIN phrm.Discounts AS di ON di.DiscountID = cl.DiscountID JOIN phrm.Sales AS sa ON sa.ClientID = cl.ClientID JOIN phrm.PharmaceuticalPreparations AS ph ON ph.MedicamentID = sa.MedicamentID
WHERE ph.Recipe = @Recipe AND sa.PurchaseAmount >= @PurchaseAmount 
)
go

