CREATE FUNCTION phrm.udfCheapPreparation(@ActiveSubstanceID INT, @Availability INT)
RETURNS NVARCHAR(70)
AS
BEGIN
	RETURN(
	SELECT TOP 1 Name
	FROM phrm.PharmaceuticalPreparations
	WHERE ActiveSubstanceID = @ActiveSubstanceID AND Availability >= @Availability
	ORDER BY Price ASC
	)
END
go

