CREATE PROCEDURE phrm.addPreparations(@ActiveSubstance NVARCHAR(50), @TypeOfExposure NVARCHAR(50), @Name NVARCHAR(70), @Availability INT, @Price MONEY, @Recipe BIT)
AS
BEGIN
	DECLARE @TypeOfExposureID INT
	DECLARE @ActiveSubstanceID INT
	IF EXISTS (SELECT ActiveSubstanceID FROM phrm.ActiveSubstance WHERE NameAS = @ActiveSubstance)
		BEGIN
		SET @ActiveSubstanceID = (SELECT ActiveSubstanceID FROM phrm.ActiveSubstance WHERE NameAS = @ActiveSubstance)
		IF EXISTS (SELECT TypeOfExposureID FROM phrm.TypeOfExposure WHERE Type = @TypeOfExposure)
			BEGIN
			SET @TypeOfExposureID = (SELECT TypeOfExposureID FROM phrm.TypeOfExposure WHERE Type = @TypeOfExposure)
			END
		ELSE 
			BEGIN
			INSERT phrm.TypeOfExposure (Type) VALUES(@TypeOfExposure)
			SET @TypeOfExposureID = (SELECT TOP 1 TypeOfExposureID FROM phrm.TypeOfExposure ORDER BY TypeOfExposureID DESC)
			END
		END
	ELSE
		BEGIN
		INSERT phrm.ActiveSubstance (NameAS) VALUES(@ActiveSubstance)
		SET @ActiveSubstanceID = (SELECT TOP 1 ActiveSubstanceID FROM phrm.ActiveSubstance ORDER BY ActiveSubstanceID DESC)
		IF EXISTS (SELECT TypeOfExposureID FROM phrm.TypeOfExposure WHERE Type = @TypeOfExposure)
			BEGIN
			SET @TypeOfExposureID = (SELECT TypeOfExposureID FROM phrm.TypeOfExposure WHERE Type = @TypeOfExposure)
			END
		ELSE 
			BEGIN
			INSERT phrm.TypeOfExposure (Type) VALUES(@TypeOfExposure)
			SET @TypeOfExposureID = (SELECT TOP 1 TypeOfExposureID FROM phrm.TypeOfExposure ORDER BY TypeOfExposureID DESC)
			END
		END
	INSERT phrm.PharmaceuticalPreparations(ActiveSubstanceID, TypeOfExposureID, Name, Availability, Price, Recipe)
	VALUES(@ActiveSubstanceID, @TypeOfExposureID, @Name, @Availability, @Price, @Recipe)
	
END

go

