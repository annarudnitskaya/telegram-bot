CREATE PROCEDURE phrm.Cheque(@MedicamentID INT, @ClientID INT, @Quantity INT)
AS
BEGIN
	IF EXISTS (SELECT MedicamentID FROM phrm.PharmaceuticalPreparations WHERE MedicamentID = @MedicamentID)
		BEGIN
		DECLARE @PurchaseAmount INT
		SET @PurchaseAmount = (SELECT Price FROM phrm.PharmaceuticalPreparations WHERE MedicamentID = @MedicamentID)*@Quantity
		INSERT phrm.Sales (MedicamentID, ClientID, PurchaseAmount) VALUES(@MedicamentID, @ClientID, @PurchaseAmount)
		UPDATE phrm.PharmaceuticalPreparations
		SET Availability = Availability - @Quantity
		WHERE MedicamentID = @MedicamentID
		DECLARE @DiscountID INT
		SET @DiscountID = (SELECT DiscountID FROM phrm.Clientes WHERE ClientID = @ClientID)
		UPDATE phrm.Discounts
		SET AmountOfRansom = AmountOfRansom + @PurchaseAmount
		WHERE DiscountID = @DiscountID
		IF ((SELECT AmountOfRansom FROM phrm.Discounts WHERE DiscountID = @DiscountID)>40000)
			BEGIN
			UPDATE phrm.Discounts
			SET DiscountPercentage = 15
			WHERE DiscountID = @DiscountID
			END
		ELSE
			IF ((SELECT AmountOfRansom FROM phrm.Discounts WHERE DiscountID = @DiscountID)>25000)
				BEGIN
				UPDATE phrm.Discounts
				SET DiscountPercentage = 12
				WHERE DiscountID = @DiscountID
				END
			ELSE 
				IF ((SELECT AmountOfRansom FROM phrm.Discounts WHERE DiscountID = @DiscountID)>15000)
					BEGIN
					UPDATE phrm.Discounts
					SET DiscountPercentage = 9
					WHERE DiscountID = @DiscountID
					END
				ELSE 
					IF ((SELECT AmountOfRansom FROM phrm.Discounts WHERE DiscountID = @DiscountID)>10000)
						BEGIN
						UPDATE phrm.Discounts
						SET DiscountPercentage = 7
						WHERE DiscountID = @DiscountID
						END
					ELSE 
						IF ((SELECT AmountOfRansom FROM phrm.Discounts WHERE DiscountID = @DiscountID)>5000)
							BEGIN
							UPDATE phrm.Discounts
							SET DiscountPercentage = 5
							WHERE DiscountID = @DiscountID
							END
						ELSE 
							BEGIN
							UPDATE phrm.Discounts
							SET DiscountPercentage = 2
							WHERE DiscountID = @DiscountID
							END
		END
END
go

