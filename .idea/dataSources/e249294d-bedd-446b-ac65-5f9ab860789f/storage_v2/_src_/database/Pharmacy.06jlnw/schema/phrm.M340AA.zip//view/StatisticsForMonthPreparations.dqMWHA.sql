CREATE VIEW phrm.StatisticsForMonthPreparations
AS
SELECT  ty.Type, ac.NameAS, ph.Name, SUM(CONVERT(INT, sa.PurchaseAmount/ph.Price)) AS SalesForMonth
FROM phrm.Sales AS sa JOIN phrm.PharmaceuticalPreparations AS ph ON ph.MedicamentID = sa.MedicamentID JOIN phrm.ActiveSubstance AS ac ON ac.ActiveSubstanceID = ph.ActiveSubstanceID JOIN phrm.TypeOfExposure AS ty ON ty.TypeOfExposureID = ph.TypeOfExposureID
WHERE ph.TypeOfExposureID = ty.TypeOfExposureID AND MONTH(sa.Date) = MONTH(GETDATE())
GROUP BY ty.Type, ac.NameAS, ph.Name

go

